print(__name__) #pacote.sub.arquivo

print(__package__) #pacote.sub