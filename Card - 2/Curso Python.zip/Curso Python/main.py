# print('Olá, Mundo!')

# import pacote.sub.arquivo
# from tipos import variaveis, basicos
# from tipos import lista, tuplas
# import tipos.conjuntos
# import tipos.dicionario
# import operadores.binarios
# import operadores.aritimeticos
# import operadores.relacionais
# import operadores.atribuicoes
# import operadores.logico
# import controle.ifs
# import controle.truefalse
# import estrutura_repeticao.forrr
# import estrutura_repeticao.whiles
# from Funções import funcao
# import input.a_b_c as num
# funcao.saudacao_pela_tarde()
# funcao.saudacao_pela_tarde('Maria')
# funcao.saudacao_pela_tarde(nome='Leonardo', idade=33)
# funcao.saudacao_pela_tarde(idade=33)
# total = funcao.soma_mult(num.valor_a, num.valor_b, num.valor_c)
# print(total)
# from Funções import args as ag
# ag.soma(1)
# ag.soma(1, 2, 3)
# packing tuple
# sum = ag.soma(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
# print(sum)
# packing dicionário
# resultado = ag.resultado_final(nome='Pedro', nota=6.3)
# print(resultado)
# from Funções import funcional
# import Funções.map_reduce
# import Funções.lambdas
# import comprehension
# import oo.produto
# import oo.heranca
import oo.membros