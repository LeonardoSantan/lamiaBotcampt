from tipos import variaveis, basicos
