valor_a = int(input("Digite o valor de a:  "))

valor_b = int(input("Digite o valor de b:  "))

valor_c = int(input("Digite o valor de c:  "))
