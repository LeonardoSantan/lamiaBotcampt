cont=0
resultado = 2

resultado +=3
print(f'Soma({cont})={resultado}')
cont+=1
#resultado = 5
resultado -=1
print(f'Subtração({cont})={resultado}')
cont+=1
#resultado = 4
resultado *=4
print(f'Multiplicação({cont})={resultado}')
cont+=1
#resultado = 16
resultado /=2
print(f'Divisão({cont})={resultado}')
cont+=1
#resultado = 8
resultado %=6
print(f'Resto({cont})={resultado}')
cont+=1
#resultado = 2







resultado = 3
print(resultado)

resultado = 'Teste'
print(resultado)