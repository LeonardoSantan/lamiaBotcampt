x = 10
y = 3
# +3 prefix
# operador vem antes do operando

# x++ postfix
# operador vem após operando

print(x + y)# sintaxe infits
print(x - y)
print(x * y)
print(x / y)
print(x % y)

par = 34
impar = 33

print(par % 2 ==0)
print(impar %2 ==0)
