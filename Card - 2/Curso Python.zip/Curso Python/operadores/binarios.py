


print(not False)
print(not True)



y = 4

print(-y)
print(--y)