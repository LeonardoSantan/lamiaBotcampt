nomes = ('Ana', 'Bia', 'Gui', 'Ana')


print(type(nomes))
print(nomes)

print('Bia' in nomes)

print(nomes[1:3])

print(nomes[2:])
#Todos valores a partir do 3
print(nomes[:-2])
#Todos valores até ante penultimo