
nums = [1, 2, 3]

print(nums)


nums.append(3)
nums.append(3)
nums.append(4)
nums.append(5)
nums.append(6)

nums.insert (0, -200)


print(len(nums))
print(nums[4])
print(nums)
