conj = {1,2,3,3,3,3,3,3,3,3,3,3,3}


# print(conj[1])

print(conj)