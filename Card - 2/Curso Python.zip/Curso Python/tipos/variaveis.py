# -*- coding: utf-8 -*-
# a = 3
# b = 4.4


# print(a + b)


# texto = 'Sua idade é ...'
# idade = 23


# print(texto + str(idade)) #transformar um inteiro em string
# interpolar valores:
# print(f'{texto} {idade}')

# print(3* 'Bom dia! ')

PI = 3.14

raio = float(input('Informe o valor de raio  '))


# area = PI * raio * raio
area = PI * pow(raio, 2)

print(f'A área do circulo é igual a: {area} m2.')