


alunos = {
    'nome': 'Pedro Santana',
    'nota': '8.0',
    'ativo': True
}


print(type(alunos))

print(alunos['nome'])
print(alunos['nota'])
print(alunos['ativo'])
print(len(alunos))