
print(notas_finais)